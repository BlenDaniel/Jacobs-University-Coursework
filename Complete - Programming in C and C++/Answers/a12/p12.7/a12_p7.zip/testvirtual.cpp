/*
CH-230-A
a4 p2.[c]
Blen Assefa
bassefa@jacobs-university.de
*/
#include <iostream>
#include <ctime>
#include <cstring>
#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"
#include "Square.h"

using namespace std;

/* A const number of object*/
const int num_obj = 25;

/* For getting a random number from 0 - 3 prototype */
int random03();

/* For getting a random number from 5 - 100 prototype */
int random5100();

int main()
{
	/* Init random number */
	srand((unsigned)time(0));
	/* A const list of char* that are the names of the objects */
	const char *obj_names[] = {"circles", "rings", "rectangles", "squares"};
	/* A const list of chat* that are colors of the objects */
	const char *obj_color[] = {"RED", "BLACK", "VIOLET", "BLUE"};

	/*
		A pointer to a list of Areas is being initiated. Since area is
		an abstract class, Area list can not be initiated. But a pointer
		to a list of Areas is possible. 

	*/
	Area *list[num_obj];
	/* 
		A integer variable called index is being initialized with a 
		0 value 
	*/
	int index = 0;
	/*
		A double variable named sum_area is being initialized with a
		value of 0.0
	*/
	double sum_area = 0.0;
	/*
		A double variable named sum_perimeter is being initialized with a
		value of 0.0
	*/
	double sum_perimeter = 0.0;

	/* Until index is 25(num_obj) the loop will be true */
	while (index < num_obj)
	{
		/* Getting a random number between the range of 0 - 3 */
		int obj_index = random03();
		/* Getting a random number between the range of 0 - 3 */
		int obj_c_index = random03();

		/* Checking to see if the randomly selected indexed name from
		 obj_names is "Circles" */
		if (strcmp(obj_names[obj_index], "circles") == 0)
		{
			cout << "Creating element " << index + 1 << " : Circles... " 
			<< endl;
			/* Object needs to be dynamically created */
			list[index++] = new Circle(obj_color[obj_c_index],
									   random5100());
		}
		/* Checking to see if the randomly selected indexed name from 
		obj_names is "rings" */
		else if (strcmp(obj_names[obj_index], "rings") == 0)
		{
			cout << "Creating element " << index + 1
				 << " :Ring... " << endl;
			/* Object needs to be dynamically created */
			list[index++] = new Ring(obj_color[obj_c_index],
									 random5100(), random5100());
		}
		/* Checking to see if the randomly selected indexed name from 
		obj_names is "rectangles" */
		else if (strcmp(obj_names[obj_index], "rectangles") == 0)
		{
			cout << "Creating element " << index + 1 << " :	Rectangle... " 
			<< endl;
			/* Object needs to be dynamically created */
			list[index++] = new Rectangle(obj_color[obj_c_index],
										  random5100(), random5100());
		}
		/* Checking to see if the randomly selected indexed 
		name from obj_names is "Square" */
		else
		{
			cout << "Creating element " << index + 1 << " : Square... " 
			<< endl;
			/* Object needs to be dynamically created */
			list[index++] = new Square(obj_color[obj_c_index],
									   random5100());
		}
	}
	/* Setting index to 0 to again iterate through the list */
	index = 0;
	/*
		Printing the value of the sum_area variable.
	*/

	while (index < num_obj)
	{
		/* Calling getColor() */
		(list[index])->getColor();
		/* Getting the perimeter of that specific index object */
		double perimeter = list[index]->perimeter();
		cout << "\nThe perimeter is: " << list[index]->perimeter() << endl;
		cout << "\nThe area is: " << list[index]->calcArea() << endl;
		/* Getting the area of that specific index object and 
		incrementing index */
		double area = list[index++]->calcArea();
		/* Adding the new area to the already sum_area value */
		sum_area += area;
		/* Adding the new area to the already sum_perimeter value */
		sum_perimeter += perimeter;
	}
	cout << "\nThe total area is "
		 << sum_area << " units " << endl;
	cout << "\nThe total perimeter is "
		 << sum_perimeter << " units \n"
		 << endl;

	delete[] * list;
	return 0;
}

/* For getting a random number from 0 - 3 function */
int random03()
{
	return (int)(rand() % 4);
}
/* For getting a random number from 5 - 100 function */
int random5100()
{
	return (int)(5 + (rand() % 95));
}
